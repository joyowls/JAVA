
public interface Icalculator {
	void monadic(double num1, int mode);
	void binomial(double num1, double num2, int mode);
	void monadicPrint();
	void binomialPrint();
}
