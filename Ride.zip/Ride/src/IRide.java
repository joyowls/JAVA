
public interface IRide {
	void information(int num1,int num2);
	void rideList();
	
}
