
public interface IUser {
	void Ticket(int num1);
	void TicketPrint();
}
